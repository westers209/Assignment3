package com.example.androidassignment3.Presenter;

import com.example.androidassignment3.Model.MusicApi;
import com.example.androidassignment3.Model.MusicPojo;
import com.example.androidassignment3.View.ViewContract;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Presenter implements PresenterContract{

    MusicApi api;
    ViewContract view;

    public Presenter(ViewContract view){
        this.view = view;
    }


    @Override
    public void bindView(ViewContract view) {
        this.view = view;
    }

    @Override
    public void initializeRetrofit() {

        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://raw.githubusercontent.com/").addConverterFactory(GsonConverterFactory.create()).build();
        api = retrofit.create(MusicApi.class);

    }

    @Override
    public void getMusic() {
        api.getMusic().enqueue(new Callback<MusicPojo>() {
            @Override
            public void onResponse(Call<MusicPojo> call, Response<MusicPojo> response) {
                view.populateMusic(response.body());
            }

            @Override
            public void onFailure(Call<MusicPojo> call, Throwable t) {
                view.onError(t.getMessage());
            }
        });
    }

    @Override
    public void onDestroy() {
        view = null;
    }
}
