package com.example.androidassignment3.View;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.androidassignment3.Model.MusicPojo;
import com.example.androidassignment3.R;
import com.squareup.picasso.Picasso;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {
    private MusicPojo dataSet;
    private Context context;

    public CustomAdapter(MusicPojo dataSet ,Context context) {
        this.dataSet = dataSet;
        this.context = context;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new CustomViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_layout,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder customViewHolder, int i) {
        customViewHolder.textViewTitle.setText(dataSet.data.get(i).getTitle());
        customViewHolder.textViewDj.setText(dataSet.data.get(i).getDj());
        customViewHolder.textViewDjMail.setText(dataSet.data.get(i).getDjmail());
        customViewHolder.textViewListeners.setText(dataSet.data.get(i).getListeners());
        customViewHolder.textViewGenre.setText(dataSet.data.get(i).getGenre());
        Picasso.get().load(dataSet.data.get(i).getImage()).into(customViewHolder.imageView);

    }

    @Override
    public int getItemCount() {
        return dataSet.data.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView textViewTitle;
        TextView textViewDj;
        TextView textViewDjMail;
        TextView textViewListeners;
        TextView textViewGenre;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.iv_image);
            textViewTitle = itemView.findViewById(R.id.tv_title);
            textViewDj = itemView.findViewById(R.id.tv_dj);
            textViewDjMail = itemView.findViewById(R.id.tv_djmail);
            textViewListeners = itemView.findViewById(R.id.tv_listeners);
            textViewGenre = itemView.findViewById(R.id.tv_genre);
        }


    }
}
