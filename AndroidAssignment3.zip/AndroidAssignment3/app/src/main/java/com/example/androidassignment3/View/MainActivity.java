package com.example.androidassignment3.View;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.androidassignment3.Model.MusicApi;
import com.example.androidassignment3.Model.MusicPojo;
import com.example.androidassignment3.Presenter.Presenter;
import com.example.androidassignment3.Presenter.PresenterContract;
import com.example.androidassignment3.R;

public class MainActivity extends AppCompatActivity implements ViewContract{

    CustomAdapter adapter;
    RecyclerView recyclerView;
    PresenterContract presenter;
    MusicPojo dataSet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CustomAdapter(dataSet, this);
        recyclerView.setAdapter(adapter);
        presenter = new Presenter(this);
        presenter.initializeRetrofit();
        presenter.getMusic();
    }

    @Override
    public void populateMusic(MusicPojo dataSet) {
    }

    @Override
    public void onError(String errorMessage) {

    }
}
