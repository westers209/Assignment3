package com.example.androidassignment3.Model;

import retrofit2.Call;
import retrofit2.http.GET;

public interface MusicApi {
    @GET("jvanaria/jvanaria.github.io/master/channels")
    Call<MusicPojo> getMusic();
}
