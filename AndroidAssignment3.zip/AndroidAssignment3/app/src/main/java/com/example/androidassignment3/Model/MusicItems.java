package com.example.androidassignment3.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MusicItems {

    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("dj")
    @Expose
    private String dj;
    @SerializedName("djmail")
    @Expose
    private String djmail;
    @SerializedName("listeners")
    @Expose
    private String listeners;
    @SerializedName("genre")
    @Expose
    private String genre;

    public void setImage(){
        this.image = image;
    }
    public String getImage(){
        return image;
    }
    public void setTitle(){
        this.title = title;
    }
    public String getTitle(){
        return title;
    }
    public void setDj(){
        this.dj = dj;
    }
    public String getDj(){
        return dj;
    }
    public void setDjmail(){
        this.djmail = djmail;
    }
    public String getDjmail(){
        return djmail;
    }
    public void setListeners(){
        this.listeners = listeners;
    }
    public String getListeners(){
        return listeners;
    }
    public void setGenre(){
        this.genre = genre;
    }
    public String getGenre(){
        return genre;
    }


}
