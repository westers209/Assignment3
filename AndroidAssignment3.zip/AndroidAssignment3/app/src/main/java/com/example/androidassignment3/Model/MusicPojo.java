package com.example.androidassignment3.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class MusicPojo {

    @SerializedName("results")
    @Expose
    public int results;

    @SerializedName("data")
    @Expose
    public List<MusicItems> data;
}
