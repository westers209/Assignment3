package com.example.androidassignment3.Presenter;

import com.example.androidassignment3.View.ViewContract;

public interface PresenterContract {
    void bindView(ViewContract view);
    void initializeRetrofit();
    void getMusic();
    void onDestroy();
}
