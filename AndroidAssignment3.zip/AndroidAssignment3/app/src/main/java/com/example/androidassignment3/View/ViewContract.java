package com.example.androidassignment3.View;

import com.example.androidassignment3.Model.MusicPojo;

public interface ViewContract {
    void populateMusic(MusicPojo dataSet);
    void onError(String errorMessage);
}
